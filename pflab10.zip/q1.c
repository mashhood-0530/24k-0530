#include<stdio.h>
int sum(int num);
main(){
	int num;
	printf("enter a number:");
	scanf("%d",&num);
printf("\n%d",sum(num));
	
}
int  sum(int num){
	int n;
	if (num==0){
		return ;
	}
	n=num%10;
	num=num/10;
	return n+sum(num);
}