#include<stdio.h>
#include<string.h>
struct package{
	char name[20];
	char destination[30];
	int price;
	int duration;//in days
	int seats;
};
void view_package(struct package p1,struct package p2,struct package p3){
	printf("(1)\nname:%s\ndestination:%s\nprice:%d\nDuration:%d\nAvailable seats:%d",p1.name,p1.destination,p1.price,p1.duration,p1.seats);
	printf("\n");
	printf("(2)\nname:%s\ndestination:%s\nprice:%d\nDuration:%d\nAvailable seats:%d",p2.name,p2.destination,p2.price,p2.duration,p2.seats);
	printf("\n");
	printf("(3)\nname:%s\ndestination:%s\nprice:%d\nDuration:%d\nAvailable seats:%d",p3.name,p3.destination,p3.price,p3.duration,p3.seats);
	printf("\n");
}
void booking(struct package p1,struct package p2,struct package p3,char p_choice[]){
	if (strcmp(p1.name,p_choice)==0){
		if (p1.seats>0){
			printf("Your booking for %s package is done",p1.name);
		}else{
			printf("No booking available for this package. Thankyou!");
		}		
	}
	else if (strcmp(p2.name,p_choice)==0){
		if (p2.seats>0){
			printf("Your booking for %s package is done",p2.name);
		}else{
			printf("No booking available for this package. Thankyou!");
		}
	}
	else if (strcmp(p3.name,p_choice)==0){
		if (p3.seats>0){
			printf("Your booking for %s package is done",p3.name);
		}else{
			printf("No booking available for this package. Thankyou!");
		}
	}
	else{
		printf("Wrong package");
	}
}
main(){
	struct package p1={"Gold","Maldives",350000,10,12};
	struct package p2={"Silver","USA",1000000,10,13};
	struct package p3={"Bronze","London",9500000,10,26};
	int choice;
	char p_choice[20];
	printf("1.View Packages \n2.Book package");
	printf("\nenter your choice: ");
	scanf("%d",&choice);
	if (choice==1){
		view_package(p1,p2,p3);
	}else if(choice==2){
		view_package(p1,p2,p3);
		printf("Enter package name:");
		scanf("%s",&p_choice);
		booking(p1,p2,p3,p_choice);
	}
		
}