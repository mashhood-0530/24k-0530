#include<stdio.h>
#define CONVERSION 1000
void convert(int l);
main(){
	int l;
	int choice;
	printf("Enter length in meters :");
	scanf("%d",&l);
	convert(l);
	do{ 
	printf("\nAnother conversion? \n 1.yes \n 2.no \n answer=");
	scanf("%d",&choice);
	if (choice==1){
	printf("\nEnter length in meters :");
	scanf("%d",&l);
	convert(l);
	}else {
		break;
	}
}while(choice==1);
	
	
}
void convert(int l){
	static int count;
	int km;
	km=l*CONVERSION;
	count++;
	printf("%d",km);
	printf("\nconversion done %d times",count);

}