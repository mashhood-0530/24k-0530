#include <stdio.h>
int linearSearch(int arr[], int size, int target, int index) {
    if (index < size && arr[index] == target) {
        return index;  
    }
    
    if (index >= size) {
        return -1;  
    }
    
    return linearSearch(arr, size, target, index + 1);
}

int main() {
    int size;
    printf("Enter array size: ");
    scanf("%d", &size);
    
    int arr[size];
    
    
    printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
    
    int target;
    
    
    printf("Enter target element: ");
    scanf("%d", &target);
    
    int result = linearSearch(arr, size, target, 0);
    
    if (result != -1) {
        printf("Target %d found at index %d.\n", target, result);
    } else {
        printf("Target %d not found in the array.\n", target);
    }
    
    return 0;
}