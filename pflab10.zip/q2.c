#include<stdio.h>
#include<string.h>
void reverse(char string[],int l,int start);
main(){
	char string[10];
	printf("Enter your string:");
	scanf("%s",string);
	int l=strlen(string);
	reverse(string,l,0);
	printf("Reversed string: %s\n", string);
}
void reverse(char string[],int l,int start){
	char temp;
	if (start>=l){
		return;
	}
	temp=string[l-1];
	string[l-1]=string[start];
	string[start]=temp;
	reverse(string,l-1,start+1);
	
	
}