#include<stdio.h>
#include<string.h>

struct flights {
    char flight_no[20];
    char depart_city[20];
    char dest_city[20];
    char date[20];
    int available_seats;
};

void booking(struct flights f1, struct flights f2, struct flights f3, struct flights f4, char f_choice[]);
void display(struct flights f1, struct flights f2, struct flights f3, struct flights f4);

int main() {
    int choice;
    char f_choice[20];  

    struct flights f1 = {"PK621", "karachi", "dubai", "12-10-2024", 24};
    struct flights f2 = {"PK548", "lahore", "jeddah", "30-10-2024", 16};
    struct flights f3 = {"PK478", "islamabad", "lahore", "16-10-2024", 4};
    struct flights f4 = {"PK120", "peshawar", "karachi", "4-10-2024", 8};

    printf("1. Book\n2. View flight details\nEnter your choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        display(f1, f2, f3, f4);
        printf("Enter flight number: ");
        scanf("%s", f_choice);  
        booking(f1, f2, f3, f4, f_choice);  
    } else if (choice == 2) {
        display(f1, f2, f3, f4);
    }

    return 0; 
}

void display(struct flights f1, struct flights f2, struct flights f3, struct flights f4) {
    printf("1. Flight number: %s\nDeparture city: %s\nDestination city: %s\nDate: %s\nAvailable seats: %d\n", 
           f1.flight_no, f1.depart_city, f1.dest_city, f1.date, f1.available_seats);
    printf("2. Flight number: %s\nDeparture city: %s\nDestination city: %s\nDate: %s\nAvailable seats: %d\n", 
           f2.flight_no, f2.depart_city, f2.dest_city, f2.date, f2.available_seats);
    printf("3. Flight number: %s\nDeparture city: %s\nDestination city: %s\nDate: %s\nAvailable seats: %d\n", 
           f3.flight_no, f3.depart_city, f3.dest_city, f3.date, f3.available_seats);
    printf("4. Flight number: %s\nDeparture city: %s\nDestination city: %s\nDate: %s\nAvailable seats: %d\n", 
           f4.flight_no, f4.depart_city, f4.dest_city, f4.date, f4.available_seats);
}

void booking(struct flights f1, struct flights f2, struct flights f3, struct flights f4, char f_choice[]) {
    if (strcmp(f1.flight_no, f_choice) == 0) {
        if (f1.available_seats > 0) {
            printf("Your booking for %s is done.\n", f1.flight_no);
        } else {
            printf("No booking available for this flight. Thank you!\n");
        }
    }
    else if (strcmp(f2.flight_no, f_choice) == 0) {
        if (f2.available_seats > 0) {
            printf("Your booking for %s is done.\n", f2.flight_no);
        } else {
            printf("No booking available for this flight. Thank you!\n");
        }
    }
    else if (strcmp(f3.flight_no, f_choice) == 0) {
        if (f3.available_seats > 0) {
            printf("Your booking for %s is done.\n", f3.flight_no);
        } else {
            printf("No booking available for this flight. Thank you!\n");
        }
    }
    else if (strcmp(f4.flight_no, f_choice) == 0) {
        if (f4.available_seats > 0) {
            printf("Your booking for %s is done.\n", f4.flight_no);
        } else {
            printf("No booking available for this flight. Thank you!\n");
        }
    }
    else {
        printf("Wrong flight number.\n");
    }
}
