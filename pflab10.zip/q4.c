#include <stdio.h>
#include <string.h>

struct movie {
    char title[30];
    char genre[20];
    char director[20];
    int release_year;
    float rating;
};

void print(struct movie m1, struct movie m2, struct movie m3, struct movie m4) {
    printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
           m1.title, m1.genre, m1.director, m1.release_year, m1.rating);
    printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
           m2.title, m2.genre, m2.director, m2.release_year, m2.rating);
    printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
           m3.title, m3.genre, m3.director, m3.release_year, m3.rating);
    printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
           m4.title, m4.genre, m4.director, m4.release_year, m4.rating);
}


void search(char s[], struct movie m1, struct movie m2, struct movie m3, struct movie m4) {
    int found = 0;

    if (strcmp(m1.genre, s) == 0) {
        printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
               m1.title, m1.genre, m1.director, m1.release_year, m1.rating);
        found = 1;
    }
    if (strcmp(m2.genre, s) == 0) {
        printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
               m2.title, m2.genre, m2.director, m2.release_year, m2.rating);
        found = 1;
    }
    if (strcmp(m3.genre, s) == 0) {
        printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
               m3.title, m3.genre, m3.director, m3.release_year, m3.rating);
        found = 1;
    }
    if (strcmp(m4.genre, s) == 0) {
        printf("\nTitle: %s\nGenre: %s\nDirector: %s\nRelease Year: %d\nRating: %.1f\n", 
               m4.title, m4.genre, m4.director, m4.release_year, m4.rating);
        found = 1;
    }

    if (!found) {
        printf("\nNo movies found with genre: %s\n", s);
    }
}

int main() {
    int choice;
    char s[20];  

    struct movie m1 = {"PK", "comedy", "xyz", 2014, 4.0};
    struct movie m2 = {"DHAMAL", "comedy", "xyz", 2006, 3.9};
    struct movie m3 = {"FAN", "horror", "xyz", 2016, 3.6};
    struct movie m4 = {"GOLMAL", "comedy", "xyz", 2007, 4.2};
    struct movie m5; 

    printf("1. View movies\n2. Search movie\n3. Add movie\nEnter your choice: ");
    scanf("%d", &choice);  

    if (choice == 3) {
        
        printf("Enter title: ");
        getchar();  
        fgets(m5.title, sizeof(m5.title), stdin);  
        m5.title[strcspn(m5.title, "\n")] = '\0';  
        printf("Enter genre: ");
        fgets(m5.genre, sizeof(m5.genre), stdin);
        m5.genre[strcspn(m5.genre, "\n")] = '\0'; 

        printf("Enter director: ");
        fgets(m5.director, sizeof(m5.director), stdin);
        m5.director[strcspn(m5.director, "\n")] = '\0';  

        printf("Enter release year: ");
        scanf("%d", &m5.release_year);

        printf("Enter rating: ");
        scanf("%f", &m5.rating);

        printf("New movie added successfully!\n");

    } else if (choice == 1) {
        
        print(m1, m2, m3, m4);
    } else {
        
        printf("Enter the genre you want to search: ");
        scanf("%s",&s); 
        search(s, m1, m2, m3, m4);
    }

    return 0;
}
