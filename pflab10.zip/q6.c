#include<stdio.h>
#include<math.h>
struct point{
	int x_cord;
	int y_cord;
};
struct rectangle{
	int x1_cord;
	int y1_cord;
	int x2_cord;
	int y2_cord;
};
float distance(struct point p1,struct point p2){
	float d=sqrt(pow((p2.x_cord-p1.x_cord),2)+pow((p2.y_cord-p1.y_cord),2));
	return d;
}
void p_check(struct rectangle r1,struct point p1){
	if (p1.x_cord>r1.x1_cord && p1.x_cord<r1.x2_cord && p1.y_cord<r1.y1_cord && p1.y_cord>r1.y2_cord){
		printf("point 1 is within the rectangle");
	}
}
main(){
	struct point p1;
	struct point p2;
	printf("Enter coordinates for point 1:\n");
	scanf("%d",&p1.x_cord);
	scanf("%d",&p1.y_cord);
	printf("Enter coordinates for point 2:\n");
	scanf("%d",&p2.x_cord);
	scanf("%d",&p2.y_cord);
	printf("%f",distance(p1,p2));
    struct rectangle r1={1,3,5,0};
    
    p_check(r1,p1);
	
	
}