#include<stdio.h>
#define max_temp 80
void check(float temp){
	static int count=0;
	if (temp<max_temp){
		printf("\nTempreture in limit");
	}else {
		count++;
		printf("\nyou entered a tempreture exceeding the limit");
		printf("\ncount for tempreture exceeding limit:%d",count);
	}
}
main(){
	float temp;
	int select;
	do{
	
	printf("\nenter tempreture:");
	scanf("%f",&temp);
	check(temp);
	printf("\nDo you want to enter any other tempreture? press 1 for yes and 2 for no : ");
	scanf("%d",&select);
	}while (select==1);
		

}