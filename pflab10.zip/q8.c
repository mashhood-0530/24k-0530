#include<stdio.h>
#include<string.h>
struct car{
	char make[20];
	int model;
    float mileage;
    float price;
};
void print(struct car c1,struct car c2,struct car c3,struct car c4){
	printf("\n %s \n %d \n %.2f \n %.2f",c1.make,c1.model,c1.mileage,c1.price);
	printf("\n %s \n %d \n %.2f \n %.2f",c2.make,c2.model,c2.mileage,c2.price);
	printf("\n %s \n %d \n %.2f \n %.2f",c3.make,c3.model,c3.mileage,c3.price);
	printf("\n %s \n %d \n %.2f \n %.2f",c4.make,c4.model,c4.mileage,c4.price);
}
void search(int smod,char smake[],struct car c1,struct car c2,struct car c3,struct car c4){
	if (strcmp(c1.make,smake)==0&&c1.model==smod){
		printf("\n %s \n %d \n %.2f \n %.2f",c1.make,c1.model,c1.mileage,c1.price);
	}else if (strcmp(c2.make,smake)==0&&smod==c2.model){
		printf("\n %s \n %d \n %.2f \n %.2f",c2.make,c2.model,c2.mileage,c2.price);
	}else if (strcmp(c3.make,smake)==0&&smod==c3.model){
		printf("\n %s \n %d \n %.2f \n %.2f", c3.make,c3.model,c3.mileage,c3.price);
	}else if (strcmp(c4.make,smake)==0&&smod==c4.model  ){
		printf("\n %s \n %d \n %.2f \n %.2f",c4.make,c4.model,c4.mileage,c4.price);
	}else {
		printf("no car available with this make or model");
	}
	
}
main(){
	int smod;
	char smake[20];
	int choice;
	struct car c1={"toyota",2009,97000,25000000};
	struct car c2={"honda",2016,100000,65000000};
	struct car c3={"suzuki",2019,30500,4000000};
	struct car c4={"suzuki",2005,206422,550000};
	struct car c5;
	printf("1.add car\n2.view available cars\n3.search car");
	printf("\nEnter you choice :");
	scanf("%d",&choice);
	if (choice==1){
		printf("enter make:");
		scanf("%s",&c5.make);
		printf("enter model:");
		scanf("%d",&c5.model);
		printf("enter mileage:");
		scanf("%f",&c5.mileage);
		printf("enter price:");
		scanf("%f",&c5.price);
		}
		else if (choice == 2){
			print(c1,c2,c3,c4);
		}else {
			printf("enter the model you want to search:");
			scanf("%d",&smod);
			printf("Enter the make you want to search:");
			scanf("%s",&smake);
			search(smod,smake,c1,c2,c3,c4);
		}
}
