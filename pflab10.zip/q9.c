#include <stdio.h>

void sort(char arr[], int l);

int main() {
    int i;
    char arr[10] = {5, 9, 4, 7, 3, 1, 2, 8, 6, 10}; 
    int l = sizeof(arr) / sizeof(arr[0]); 
	sort(arr, l);
    for (i = 0; i < l; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}


void sort(char arr[], int l) {
    int temp;
    if (l <= 1) {
        return;
    }

    for (int i = 0; i < l - 1; i++) {
        if (arr[i] < arr[i + 1]) { 
            temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;
        }
    }

    
    sort(arr, l - 1);
}